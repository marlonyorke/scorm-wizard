import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import ScormPlayer from '../ScormPlayer';
import { ScormProvider } from '@/contexts/ScormContext';
import type { SCORMAPI } from '@/utils/scormAPI';

// Create a partial mock of SCORMAPI
const mockScormAPI = {
  initialized: false,
  terminated: false,
  lastError: '0',
  studentData: {
    score: 0,
    status: 'not attempted' as const,
    suspend_data: '',
  },
  handleMessage: vi.fn(),
  sendToParent: vi.fn(),
  LMSInitialize: vi.fn(() => 'true'),
  LMSFinish: vi.fn(() => 'true'),
  LMSGetValue: vi.fn(),
  LMSSetValue: vi.fn(() => 'true'),
  LMSCommit: vi.fn(() => 'true'),
  LMSGetLastError: vi.fn(() => '0'),
  LMSGetErrorString: vi.fn(),
  LMSGetDiagnostic: vi.fn(),
} as unknown as SCORMAPI;

describe('ScormPlayer', () => {
  beforeEach(() => {
    // Setup mock SCORM API
    window.API = mockScormAPI;
    
    // Reset all mocks before each test
    vi.clearAllMocks();
  });

  afterEach(() => {
    // Cleanup
    delete window.API;
  });

  it('initializes SCORM API on mount', () => {
    render(
      <ScormProvider>
        <ScormPlayer />
      </ScormProvider>
    );
    
    expect(mockScormAPI.LMSInitialize).toHaveBeenCalledTimes(1);
  });

  it('shows error alert when initialization fails', () => {
    vi.spyOn(mockScormAPI, 'LMSInitialize').mockReturnValue('false');
    vi.spyOn(mockScormAPI, 'LMSGetLastError').mockReturnValue('101');
    
    render(
      <ScormProvider>
        <ScormPlayer />
      </ScormProvider>
    );
    
    expect(screen.getByText(/SCORM niet geïnitialiseerd/i)).toBeInTheDocument();
  });

  it('terminates SCORM API on unmount', () => {
    const { unmount } = render(
      <ScormProvider>
        <ScormPlayer />
      </ScormProvider>
    );
    
    unmount();
    expect(mockScormAPI.LMSFinish).toHaveBeenCalledTimes(1);
  });

  it('updates score and status correctly', () => {
    render(
      <ScormProvider>
        <ScormPlayer />
      </ScormProvider>
    );
    
    // Simulate score update
    vi.spyOn(mockScormAPI, 'LMSSetValue').mockImplementation((element: string, value: string): 'true' | 'false' => {
      if (element === 'cmi.core.score.raw' && value === '80') return 'true';
      if (element === 'cmi.core.lesson_status' && value === 'completed') return 'true';
      return 'false';
    });

    // Find and click the test score button (assuming it exists in ScormDebugger)
    const scoreButton = screen.getByText(/Test Score/i);
    fireEvent.click(scoreButton);

    expect(mockScormAPI.LMSSetValue).toHaveBeenCalledWith('cmi.core.score.raw', expect.any(String));
    expect(mockScormAPI.LMSCommit).toHaveBeenCalled();
  });

  it('handles suspend data persistence', () => {
    render(
      <ScormProvider>
        <ScormPlayer />
      </ScormProvider>
    );

    const testData = JSON.stringify({ progress: 50 });
    vi.spyOn(mockScormAPI, 'LMSSetValue').mockImplementation((element: string, value: string): 'true' | 'false' => {
      if (element === 'cmi.suspend_data' && value === testData) return 'true';
      return 'false';
    });

    // Find and click the test suspend data button (assuming it exists in ScormDebugger)
    const suspendButton = screen.getByText(/Test Suspend Data/i);
    fireEvent.click(suspendButton);

    expect(mockScormAPI.LMSSetValue).toHaveBeenCalledWith('cmi.suspend_data', expect.any(String));
    expect(mockScormAPI.LMSCommit).toHaveBeenCalled();
  });
});