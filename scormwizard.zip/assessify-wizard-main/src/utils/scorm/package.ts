
import JSZip from "jszip";
import { Question } from "@/types/editor";
import { createManifest } from "./manifest";
import { QuestionRegistry } from "./registry";
import { BaseRenderer } from "./renderers/base";

export interface ScormExportOptions {
  displayMode: 'single-page' | 'multi-page' | 'grouped';
  questionsPerGroup?: number;
}

export const generateScormPackage = async (
  questions: Question[],
  options: ScormExportOptions = { displayMode: 'single-page' }
) => {
  const zip = new JSZip();

  // Add manifest file
  const manifestContent = createManifest(questions);
  zip.file('imsmanifest.xml', manifestContent);

  // Add SCORM API script
  const scormAPIScript = `
    var API = {
      LMSInitialize: function() { return "true"; },
      LMSFinish: function() { return "true"; },
      LMSGetValue: function(element) { return ""; },
      LMSSetValue: function(element, value) { return "true"; },
      LMSCommit: function() { return "true"; },
      LMSGetLastError: function() { return "0"; },
      LMSGetErrorString: function() { return ""; },
      LMSGetDiagnostic: function() { return ""; }
    };
  `;
  zip.file('scripts/scormAPI.js', scormAPIScript);

  // Generate quiz HTML
  const quizHTML = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8">
        <title>Quiz</title>
        <script src="scripts/scormAPI.js"></script>
        <style>
          body {
            font-family: system-ui, -apple-system, sans-serif;
            line-height: 1.5;
            max-width: 800px;
            margin: 0 auto;
            padding: 2rem;
          }
          .question {
            margin-bottom: 2rem;
            padding: 1rem;
            border: 1px solid #e2e8f0;
            border-radius: 0.5rem;
          }
          button {
            padding: 0.5rem 1rem;
            background-color: #2563eb;
            color: white;
            border: none;
            border-radius: 0.25rem;
            cursor: pointer;
          }
          button:hover {
            background-color: #1d4ed8;
          }
        </style>
      </head>
      <body>
        <div id="quiz-container">
          ${questions.map((question, index) => {
            const renderer = QuestionRegistry.getRenderer(question.type);
            if (renderer instanceof BaseRenderer) {
              return `
                <div class="question" id="question-${index}">
                  ${renderer.render(question)}
                </div>
              `;
            }
            return '';
          }).join('\n')}
        </div>
        <script>
          window.onload = function() {
            if (typeof API !== 'undefined') {
              API.LMSInitialize('');
            }
          };
          window.onunload = function() {
            if (typeof API !== 'undefined') {
              API.LMSFinish('');
            }
          };
        </script>
      </body>
    </html>
  `;

  // Add quiz HTML to zip
  zip.file('index.html', quizHTML);

  // Generate and download zip
  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'quiz.zip';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  return true;
};
