import { Question } from "@/types/editor";
import { ScormQuestionRenderer } from "../types/questions";

export abstract class BaseRenderer implements ScormQuestionRenderer {
  abstract render(question: Question): string;
  abstract validateAnswer(question: Question, answer: any): boolean;
  abstract calculateScore(question: Question, answer: any): number;
  
  protected createScormWrapper(content: string): string {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Quiz</title>
          <script src="scripts/scormAPI.js"></script>
        </head>
        <body>
          ${content}
          <script>
            window.onload = () => {
              if (API) {
                API.LMSInitialize("");
                API.LMSSetValue("cmi.core.lesson_status", "incomplete");
                API.LMSCommit("");
              }
            };
            
            window.onunload = () => {
              if (API) {
                API.LMSFinish("");
              }
            };
          </script>
        </body>
      </html>
    `;
  }
}