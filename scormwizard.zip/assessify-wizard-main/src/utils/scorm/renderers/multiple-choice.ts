import { Question } from "@/types/editor";
import { BaseRenderer } from "./base";

export class MultipleChoiceRenderer extends BaseRenderer {
  render(question: Question): string {
    const content = `
      <div class="question">
        <h2>${question.text}</h2>
        ${question.mediaUrl ? `
          <div class="question-media">
            <img 
              src="${question.mediaUrl}" 
              alt="Question media"
              style="width: ${question.imageSize?.width || 300}px; height: ${question.imageSize?.height || 200}px; object-fit: contain;"
            >
          </div>
        ` : ''}
        <div class="options">
          ${question.options?.map(option => `
            <label class="option">
              <input 
                type="radio" 
                name="question${question.id}" 
                value="${option.id}"
                onchange="handleAnswer('${option.id}')"
              >
              ${option.text}
            </label>
          `).join('')}
        </div>
      </div>
    `;

    return this.createScormWrapper(content);
  }

  validateAnswer(question: Question, answer: any): boolean {
    const correctOption = question.options?.find(option => option.isCorrect);
    return correctOption?.id === answer;
  }

  calculateScore(question: Question, answer: any): number {
    return this.validateAnswer(question, answer) ? 100 : 0;
  }
}