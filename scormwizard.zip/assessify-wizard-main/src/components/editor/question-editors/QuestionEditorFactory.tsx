import { Question } from "@/types/editor";
import { MarkWordsQuestionEditor } from "../question-types/MarkWordsQuestionEditor";
import { MultipleChoiceQuestionEditor } from "../question-types/MultipleChoiceQuestionEditor";
import { MatchingQuestionEditor } from "../question-types/MatchingQuestionEditor";
import { OrderQuestionEditor } from "../question-types/OrderQuestionEditor";
import { DragDropQuestionEditor } from "../question-types/DragDropQuestionEditor";
import { BaseQuestionEditor, ValidationError } from "./base/BaseQuestionEditor";

interface QuestionEditorFactoryProps {
  currentQuestion: Question;
  onQuestionChange: (question: Question) => void;
  onAddOption?: () => void;
  onOptionChange?: (optionId: string, newText: string) => void;
  onRemoveOption?: (optionId: string) => void;
  showNameField?: boolean;
}

export function QuestionEditorFactory({ 
  currentQuestion, 
  onQuestionChange,
  onAddOption,
  onOptionChange,
  onRemoveOption,
  showNameField = true
}: QuestionEditorFactoryProps) {
  console.log("🔄 Rendering QuestionEditorFactory...");
  console.log("👉 Huidig vraagtype:", currentQuestion.type);
  console.log("📦 Complete vraag object:", currentQuestion);

  // Type-specifieke validatie functies
  const validateMarkWordsQuestion = (question: Question): ValidationError[] => {
    console.log("🔍 Validating mark-words question:", question);
    const baseErrors = BaseQuestionEditor.validateQuestion(question);
    const typeErrors: ValidationError[] = [];

    if (question.type === 'mark-words' && (!question.words || question.words.length === 0)) {
      typeErrors.push({
        field: "words",
        message: "Markeer minimaal één woord in de tekst"
      });
    }

    const allErrors = [...baseErrors, ...typeErrors];
    console.log("❌ Mark words validation errors:", allErrors);
    return allErrors;
  };

  const validateMultipleChoiceQuestion = (question: Question): ValidationError[] => {
    console.log("🔍 Validating multiple-choice question:", question);
    const baseErrors = BaseQuestionEditor.validateQuestion(question);
    const typeErrors: ValidationError[] = [];

    if (question.type === 'multiple-choice') {
      if (!question.options || question.options.length < 2) {
        typeErrors.push({
          field: "options",
          message: "Voeg minimaal twee antwoordopties toe"
        });
      } else {
        const hasCorrectAnswer = question.options.some(opt => opt.isCorrect);
        if (!hasCorrectAnswer) {
          typeErrors.push({
            field: "options",
            message: "Selecteer minimaal één correct antwoord"
          });
        }
      }
    }

    const allErrors = [...baseErrors, ...typeErrors];
    console.log("❌ Multiple choice validation errors:", allErrors);
    return allErrors;
  };

  const validateMatchingQuestion = (question: Question): ValidationError[] => {
    console.log("🔍 Validating matching question:", question);
    const baseErrors = BaseQuestionEditor.validateQuestion(question);
    const typeErrors: ValidationError[] = [];

    if (question.type === 'matching') {
      if (!question.pairs || question.pairs.length < 2) {
        typeErrors.push({
          field: "pairs",
          message: "Voeg minimaal twee paren toe"
        });
      } else {
        const invalidPairs = question.pairs.some(
          pair => !pair.left.trim() || !pair.right.trim()
        );
        if (invalidPairs) {
          typeErrors.push({
            field: "pairs",
            message: "Vul beide delen van elk paar in"
          });
        }
      }
    }

    const allErrors = [...baseErrors, ...typeErrors];
    console.log("❌ Matching validation errors:", allErrors);
    return allErrors;
  };

  // Selecteer de juiste editor op basis van het vraagtype
  console.log("🎯 Selecting editor for question type:", currentQuestion.type);
  
  switch (currentQuestion.type) {
    case 'mark-words':
      console.log("✅ Rendering MarkWordsQuestionEditor");
      return (
        <MarkWordsQuestionEditor
          currentQuestion={currentQuestion}
          onQuestionChange={onQuestionChange}
          validateQuestion={validateMarkWordsQuestion}
          showNameField={showNameField}
        />
      );
    
    case 'multiple-choice':
      console.log("✅ Rendering MultipleChoiceQuestionEditor");
      return (
        <MultipleChoiceQuestionEditor
          currentQuestion={currentQuestion}
          onQuestionChange={onQuestionChange}
          validateQuestion={validateMultipleChoiceQuestion}
          onAddOption={onAddOption}
          onOptionChange={onOptionChange}
          onRemoveOption={onRemoveOption}
          showNameField={showNameField}
        />
      );
    
    case 'matching':
      console.log("✅ Rendering MatchingQuestionEditor");
      return (
        <MatchingQuestionEditor
          currentQuestion={currentQuestion}
          onQuestionChange={onQuestionChange}
          validateQuestion={validateMatchingQuestion}
          showNameField={showNameField}
        />
      );

    case 'order':
      console.log("✅ Rendering OrderQuestionEditor");
      return (
        <OrderQuestionEditor
          currentQuestion={currentQuestion}
          onQuestionChange={onQuestionChange}
          showNameField={showNameField}
        />
      );

    case 'drag-drop':
      console.log("✅ Rendering DragDropQuestionEditor");
      if (!currentQuestion.items || !currentQuestion.dropZones) {
        console.error("Missing required properties for drag-drop question");
        return null;
      }
      
      // Ensure we're dealing with DragDropItem[] and not OrderItem[]
      if (currentQuestion.items.some(item => 'correctPosition' in item)) {
        console.error("Invalid items type for drag-drop question");
        return null;
      }

      return (
        <DragDropQuestionEditor
          currentQuestion={currentQuestion as any}
          onQuestionChange={onQuestionChange}
          showNameField={showNameField}
        />
      );
    
    default:
      console.error("🚨 ERROR: Onbekend vraagtype!", currentQuestion.type);
      return null;
  }
}
