import { Question } from "@/types/editor";
import { QuestionEditorFactory } from "./question-editors/QuestionEditorFactory";

interface QuestionEditorFormProps {
  currentQuestion: Question;
  onQuestionChange: (question: Question) => void;
  onAddOption: () => void;
  onOptionChange: (optionId: string, newText: string) => void;
  onRemoveOption: (optionId: string) => void;
  showNameField?: boolean;
}

export function QuestionEditorForm({
  currentQuestion,
  onQuestionChange,
  onAddOption,
  onOptionChange,
  onRemoveOption,
  showNameField = true,
}: QuestionEditorFormProps) {
  if (!currentQuestion) {
    console.log("QuestionEditorForm: No current question provided");
    return null;
  }

  console.log("QuestionEditorForm rendering with question:", {
    id: currentQuestion.id,
    type: currentQuestion.type,
    name: currentQuestion.name,
    text: currentQuestion.text
  });
  
  return (
    <QuestionEditorFactory
      currentQuestion={currentQuestion}
      onQuestionChange={onQuestionChange}
      onAddOption={onAddOption}
      onOptionChange={onOptionChange}
      onRemoveOption={onRemoveOption}
      showNameField={showNameField}
    />
  );
}