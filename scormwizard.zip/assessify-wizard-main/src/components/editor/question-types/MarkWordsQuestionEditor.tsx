
import { Question } from "@/types/editor";
import { withBaseQuestionEditor, BaseQuestionEditorProps } from "../question-editors/base/BaseQuestionEditor";
import { MarkWordsEditor } from "../form/MarkWordsEditor";

interface MarkWordsQuestionEditorProps extends BaseQuestionEditorProps {
  currentQuestion: Question;
  onQuestionChange: (question: Question) => void;
  validateQuestion?: (question: Question) => any[];
  showNameField?: boolean;
}

function MarkWordsQuestionEditorComponent({
  currentQuestion,
  onQuestionChange,
  showNameField = true
}: MarkWordsQuestionEditorProps) {
  return (
    <MarkWordsEditor
      currentQuestion={currentQuestion}
      onQuestionChange={onQuestionChange}
      showNameField={showNameField}
    />
  );
}

export const MarkWordsQuestionEditor = withBaseQuestionEditor(MarkWordsQuestionEditorComponent);
