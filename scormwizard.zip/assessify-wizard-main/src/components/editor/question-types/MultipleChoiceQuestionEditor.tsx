import { Question } from "@/types/editor";
import { withBaseQuestionEditor, ValidationError } from "../question-editors/base/BaseQuestionEditor";
import { AnswerOptions } from "../form/AnswerOptions";
import { EditableText } from "../form/EditableText";
import { MultipleChoicePreview } from "../../questions/preview/MultipleChoicePreview";
import { MediaUpload } from "../form/MediaUpload";

interface MultipleChoiceQuestionEditorProps {
  currentQuestion: Question;
  onQuestionChange: (question: Question) => void;
  validateQuestion?: (question: Question) => ValidationError[];
  onAddOption?: () => void;
  onOptionChange?: (optionId: string, newText: string) => void;
  onRemoveOption?: (optionId: string) => void;
  showNameField?: boolean;
}

function MultipleChoiceQuestionEditorBase({
  currentQuestion,
  onQuestionChange,
  onAddOption,
  onOptionChange,
  onRemoveOption,
}: MultipleChoiceQuestionEditorProps) {

  const handleMediaChange = (mediaUrl: string | undefined, imageSize?: { width: number; height: number }) => {
    onQuestionChange({
      ...currentQuestion,
      mediaUrl,
      imageSize
    });
  };

  const handleQuestionTextChange = (newText: string) => {
    onQuestionChange({
      ...currentQuestion,
      text: newText
    });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <label className="text-sm font-medium">Vraag</label>
        <EditableText
          value={currentQuestion.text}
          onSave={handleQuestionTextChange}
          placeholder="Typ hier je vraag..."
        />
      </div>

      <AnswerOptions
        currentQuestion={currentQuestion}
        onQuestionChange={onQuestionChange}
        onAddOption={onAddOption}
        onOptionChange={onOptionChange}
        onRemoveOption={onRemoveOption}
      />

      <MediaUpload 
        media={currentQuestion.mediaUrl}
        imageSize={currentQuestion.imageSize}
        onMediaChange={handleMediaChange}
      />

      <div className="border-t pt-6 mt-6">
        <h3 className="text-lg font-medium mb-4">Voorvertoning</h3>
        <div className="bg-gray-50 rounded-lg border p-4">
          <MultipleChoicePreview
            text={currentQuestion.text}
            options={currentQuestion.options || []}
            multipleCorrect={currentQuestion.multipleCorrect}
            feedback={currentQuestion.feedback}
            mediaUrl={currentQuestion.mediaUrl}
            imageSize={currentQuestion.imageSize}
          />
        </div>
      </div>
    </div>
  );
}

export const MultipleChoiceQuestionEditor = withBaseQuestionEditor(MultipleChoiceQuestionEditorBase);
