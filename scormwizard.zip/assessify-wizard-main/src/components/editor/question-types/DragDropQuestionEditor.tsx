import React, { useState, useEffect } from 'react';
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info } from "lucide-react";
import { withBaseQuestionEditor, BaseQuestionEditorProps } from '../question-editors/base/BaseQuestionEditor';
import { Question, DragDropItem, DragDropZone } from '@/types/editor';
import { MediaUpload } from '../form/MediaUpload';
import { DragDropQuestionPreview } from './components/DragDropQuestionPreview';
import { useSensors, useSensor, PointerSensor, DragEndEvent } from '@dnd-kit/core';

interface DragDropQuestion extends Omit<Question, 'items'> {
  type: 'drag-drop';
  items: DragDropItem[];
  dropZones: DragDropZone[];
}

interface DragDropQuestionEditorProps extends BaseQuestionEditorProps {
  currentQuestion: DragDropQuestion;
}

function DragDropQuestionEditorComponent({
  currentQuestion,
  onQuestionChange,
}: DragDropQuestionEditorProps) {
  const [fullText, setFullText] = useState('');

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const handleTextChange = (text: string) => {
    setFullText(text);
    
    // Extraheer woorden tussen asterisken en maak er items en dropzones van
    const items: DragDropItem[] = [];
    const dropZones: DragDropZone[] = [];
    const regex = /\*(.*?)\*/g;
    let lastIndex = 0;
    let match;
    
    while ((match = regex.exec(text)) !== null) {
      const beforeText = text.slice(lastIndex, match.index);
      const word = match[1];
      lastIndex = match.index + match[0].length;
      
      // Maak een nieuw sleepbaar item
      const newItem: DragDropItem = {
        id: crypto.randomUUID(),
        text: word,
      };
      items.push(newItem);
      
      // Maak een nieuwe dropzone voor dit item
      const newZone: DragDropZone = {
        id: crypto.randomUUID(),
        beforeText: beforeText.trim(),
        afterText: '',
        correctItemId: newItem.id,
      };
      dropZones.push(newZone);
    }
    
    // Voeg de laatste tekst toe aan de laatste dropzone
    if (dropZones.length > 0 && lastIndex < text.length) {
      dropZones[dropZones.length - 1].afterText = text.slice(lastIndex).trim();
    }

    onQuestionChange({
      ...currentQuestion,
      items,
      dropZones
    });
  };

  const handleMediaChange = (mediaUrl: string | undefined, imageSize?: { width: number; height: number }) => {
    onQuestionChange({
      ...currentQuestion,
      mediaUrl,
      imageSize
    });
  };

  const handleDragEnd = (event: DragEndEvent) => {
    // In de preview hoeven we niets te doen met drag events
    console.log('Drag ended:', event);
  };

  useEffect(() => {
    if (fullText === '' && currentQuestion.dropZones.length > 0) {
      let text = '';
      currentQuestion.dropZones.forEach((zone, index) => {
        const item = currentQuestion.items.find(item => item.id === zone.correctItemId);
        text += zone.beforeText;
        text += item ? `*${item.text}*` : '**';
        text += zone.afterText;
        if (index < currentQuestion.dropZones.length - 1) {
          text += ' ';
        }
      });
      setFullText(text);
    }
  }, []);

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="questionText">Opdracht</Label>
        <Input
          id="questionText"
          value={currentQuestion.text}
          onChange={(e) => onQuestionChange({
            ...currentQuestion,
            text: e.target.value
          })}
          placeholder="Bijvoorbeeld: Vul de ontbrekende woorden in"
        />
      </div>

      <MediaUpload 
        media={currentQuestion.mediaUrl}
        imageSize={currentQuestion.imageSize}
        onMediaChange={handleMediaChange}
      />

      <div className="space-y-4">
        <Label>Tekst met invulplaatsen</Label>
        <Alert>
          <AlertDescription className="flex items-center gap-2">
            <Info className="h-4 w-4" />
            Plaats asterisken (*) rond de woorden die versleept moeten worden
          </AlertDescription>
        </Alert>
        <Card className="p-4">
          <Textarea
            value={fullText}
            onChange={(e) => handleTextChange(e.target.value)}
            placeholder="Bijvoorbeeld: Een DNA-molecuul bestaat uit twee strengen van *nucleotiden*."
            rows={5}
          />
        </Card>
      </div>

      <DragDropQuestionPreview
        text={currentQuestion.text}
        items={currentQuestion.items}
        dropZones={currentQuestion.dropZones}
        mediaUrl={currentQuestion.mediaUrl}
        imageSize={currentQuestion.imageSize}
        sensors={sensors}
        onDragEnd={handleDragEnd}
      />
    </div>
  );
}

export const DragDropQuestionEditor = withBaseQuestionEditor<DragDropQuestionEditorProps>(DragDropQuestionEditorComponent);
