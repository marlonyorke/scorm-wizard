
import React from 'react';
import { DndContext, closestCenter, DragEndEvent } from '@dnd-kit/core';
import { SortableContext, useSortable } from '@dnd-kit/sortable';
import { DragDropItem, DragDropZone } from '@/types/editor';
import { CSS } from '@dnd-kit/utilities';

interface DragDropQuestionPreviewProps {
  text: string;
  items: DragDropItem[];
  dropZones: DragDropZone[];
  mediaUrl?: string;
  imageSize?: {
    width: number;
    height: number;
  };
  sensors: any;
  onDragEnd: (event: DragEndEvent) => void;
}

const DraggableItem = ({ id, text }: { id: string; text: string }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className="inline-block bg-secondary text-secondary-foreground rounded px-3 py-1 m-1 cursor-move hover:bg-secondary/80"
    >
      {text}
    </div>
  );
};

const DropZone = ({ beforeText, afterText }: { beforeText: string; afterText: string }) => {
  return (
    <div className="flex items-center gap-2 mb-2">
      <span>{beforeText}</span>
      <div className="w-32 h-8 border-2 border-dashed border-border rounded bg-muted"></div>
      <span>{afterText}</span>
    </div>
  );
};

export const DragDropQuestionPreview = ({
  text,
  items,
  dropZones,
  mediaUrl,
  imageSize,
  sensors,
  onDragEnd,
}: DragDropQuestionPreviewProps) => {
  return (
    <div className="border-t border-border pt-6 mt-6">
      <h3 className="text-lg font-medium mb-4">Voorvertoning</h3>
      <div className="bg-card text-card-foreground rounded-lg border border-border p-4">
        <div className="space-y-4">
          <p className="font-medium">{text}</p>
          
          {mediaUrl && (
            <img 
              src={mediaUrl} 
              alt="Vraag afbeelding"
              className="rounded-lg max-w-full h-auto"
              style={{
                width: imageSize?.width || 300,
                height: imageSize?.height || 200,
                objectFit: 'contain'
              }}
            />
          )}

          <div className="space-y-4">
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={onDragEnd}
            >
              <div className="mb-4">
                <SortableContext items={items.map(item => item.id)}>
                  {items.map((item) => (
                    <DraggableItem key={item.id} id={item.id} text={item.text} />
                  ))}
                </SortableContext>
              </div>

              <div className="space-y-2">
                {dropZones.map((zone) => (
                  <DropZone
                    key={zone.id}
                    beforeText={zone.beforeText}
                    afterText={zone.afterText}
                  />
                ))}
              </div>
            </DndContext>
          </div>
        </div>
      </div>
    </div>
  );
};
