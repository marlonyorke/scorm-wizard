
import React, { useState } from 'react';
import { Question } from "@/types/editor";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info } from "lucide-react";
import { MediaUpload } from "./MediaUpload";
import { MarkWordsPreview } from "@/components/questions/preview/MarkWordsPreview";

interface MarkWordsEditorProps {
  currentQuestion: Question;
  onQuestionChange: (question: Question) => void;
  showNameField?: boolean;
}

export function MarkWordsEditor({ 
  currentQuestion, 
  onQuestionChange
}: MarkWordsEditorProps) {
  const [text, setText] = useState(currentQuestion.text || '');

  const handleTextChange = (value: string) => {
    // Update de tekst
    setText(value);
    
    // Extraheer woorden tussen dakjes
    const words = [];
    const regex = /\^(.*?)\^/g;
    let match;
    
    while ((match = regex.exec(value)) !== null) {
      words.push({
        id: crypto.randomUUID(),
        word: match[1],
        isCorrect: true
      });
    }

    // Update de vraag
    onQuestionChange({
      ...currentQuestion,
      text: value,
      words: words,
      maxErrors: currentQuestion.maxErrors || 2 // Default waarde voor maximaal aantal fouten
    });
  };

  const handleQuestionChange = (questionText: string) => {
    onQuestionChange({
      ...currentQuestion,
      question: questionText
    });
  };

  const handleMaxErrorsChange = (value: string) => {
    const maxErrors = parseInt(value) || 0;
    onQuestionChange({
      ...currentQuestion,
      maxErrors: Math.max(0, maxErrors) // Zorg dat het niet negatief kan zijn
    });
  };

  const handleMediaChange = (mediaUrl: string | undefined, imageSize?: { width: number; height: number }) => {
    onQuestionChange({
      ...currentQuestion,
      mediaUrl,
      imageSize
    });
  };

  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <Label>Vraag (optioneel)</Label>
        <Input
          placeholder="Bijvoorbeeld: Markeer alle werkwoorden in de tekst"
          value={currentQuestion.question || ''}
          onChange={(e) => handleQuestionChange(e.target.value)}
        />
      </div>

      <div className="space-y-4">
        <Label>Maximum aantal fouten voor een voldoende</Label>
        <Input
          type="number"
          min="0"
          placeholder="Bijvoorbeeld: 2"
          value={currentQuestion.maxErrors || ''}
          onChange={(e) => handleMaxErrorsChange(e.target.value)}
        />
        <p className="text-sm text-gray-500">
          Geef aan hoeveel fouten een leerling mag maken om nog een voldoende te halen
        </p>
      </div>

      <div className="space-y-4">
        <Label>Tekst met te markeren woorden</Label>
        <Alert>
          <AlertDescription className="flex items-center gap-2">
            <Info className="h-4 w-4" />
            Plaats dakjes (^) rond de woorden die gemarkeerd moeten worden
          </AlertDescription>
        </Alert>
        <Textarea
          placeholder="Bijvoorbeeld: De ^kat^ ^sloop^ stilletjes door de tuin."
          value={text}
          onChange={(e) => handleTextChange(e.target.value)}
          rows={5}
        />
      </div>

      <MediaUpload 
        media={currentQuestion.mediaUrl}
        imageSize={currentQuestion.imageSize}
        onMediaChange={handleMediaChange}
      />

      <div className="rounded-lg border p-4">
        <h3 className="text-lg font-medium mb-4">Preview</h3>
        <MarkWordsPreview
          text={currentQuestion.text}
          question={currentQuestion.question}
          words={currentQuestion.words || []}
          mediaUrl={currentQuestion.mediaUrl}
          imageSize={currentQuestion.imageSize}
          maxErrors={currentQuestion.maxErrors}
        />
      </div>
    </div>
  );
}
