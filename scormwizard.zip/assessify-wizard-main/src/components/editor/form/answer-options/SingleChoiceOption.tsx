
import { Question } from "@/types/editor";
import { Button } from "@/components/ui/button";
import { EditableText } from "../EditableText";
import { RadioGroupItem } from "@/components/ui/radio-group";
import { Trash2, Image as ImageIcon } from "lucide-react";
import { MediaUpload } from "../MediaUpload";
import { ResizableImage } from "@/components/questions/preview/ResizableImage";
import { useState } from "react";

interface SingleChoiceOptionProps {
  option: { 
    id: string; 
    text: string; 
    isCorrect: boolean;
    mediaUrl?: string;
    imageSize?: {
      width: number;
      height: number;
    };
  };
  selectedOptionId?: string;
  onOptionChange: (optionId: string, newText: string) => void;
  onCorrectAnswerChange: (optionId: string) => void;
  onRemoveOption: (optionId: string) => void;
  onMediaChange?: (optionId: string, mediaUrl: string | undefined, imageSize?: { width: number; height: number }) => void;
}

export function SingleChoiceOption({
  option,
  selectedOptionId,
  onOptionChange,
  onCorrectAnswerChange,
  onRemoveOption,
  onMediaChange,
}: SingleChoiceOptionProps) {
  const [showMediaUpload, setShowMediaUpload] = useState(false);

  const handleMediaChange = (mediaUrl: string | undefined, imageSize?: { width: number; height: number }) => {
    onMediaChange?.(option.id, mediaUrl, imageSize);
    setShowMediaUpload(false);
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center space-x-2">
        <RadioGroupItem
          checked={option.id === selectedOptionId}
          onClick={() => onCorrectAnswerChange(option.id)}
          value={option.id}
        />
        <div className="flex-1">
          <EditableText
            value={option.text}
            onSave={(newText) => onOptionChange(option.id, newText)}
            placeholder="Voer antwoordoptie in..."
          />
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setShowMediaUpload(!showMediaUpload)}
          className="h-10 w-10"
        >
          <ImageIcon className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={() => onRemoveOption(option.id)}
          className="h-10 w-10"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>

      {showMediaUpload && (
        <div className="pl-8">
          <MediaUpload 
            media={option.mediaUrl}
            imageSize={option.imageSize}
            onMediaChange={handleMediaChange}
          />
        </div>
      )}

      {option.mediaUrl && !showMediaUpload && (
        <div className="pl-8 pt-2">
          <ResizableImage
            src={option.mediaUrl}
            alt={`Afbeelding voor optie ${option.text}`}
            initialSize={option.imageSize}
            className="rounded-lg"
          />
        </div>
      )}
    </div>
  );
}
