
import { Question } from "@/types/editor";
import { Label } from "@/components/ui/label";
import { Upload } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface MediaUploadProps {
  media?: string;
  imageSize?: {
    width: number;
    height: number;
  };
  onMediaChange: (mediaUrl: string | undefined, imageSize?: { width: number; height: number }) => void;
}

export function MediaUpload({ media, imageSize, onMediaChange }: MediaUploadProps) {
  const { toast } = useToast();

  const handleMediaUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast({
        variant: "destructive",
        title: "Fout bij uploaden",
        description: "Het bestand is te groot. Maximum grootte is 5MB.",
      });
      return;
    }

    try {
      const base64String = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            resolve(reader.result);
          } else {
            reject(new Error('Failed to convert file to base64'));
          }
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      onMediaChange(base64String, { width: 300, height: 200 });

      // Reset the file input after successful upload
      if (event.target) {
        event.target.value = '';
      }

      toast({
        title: "Media geüpload",
        description: "De afbeelding is succesvol toegevoegd.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Fout bij uploaden",
        description: "Er is een fout opgetreden bij het verwerken van het bestand.",
      });
    }
  };

  return (
    <div className="border-2 border-dashed rounded-lg p-6">
      <input
        type="file"
        accept="image/png,image/jpeg,image/gif"
        className="hidden"
        id="media-upload"
        onChange={handleMediaUpload}
      />
      <label htmlFor="media-upload" className="cursor-pointer block">
        <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground text-center">
          Sleep bestanden hierheen of klik om te uploaden
        </p>
        <p className="text-xs text-muted-foreground mt-1 text-center">
          PNG, JPG of GIF (max. 5MB)
        </p>
      </label>
    </div>
  );
}
