
import { Question } from "@/types/editor";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Plus } from "lucide-react";
import { Toggle } from "@/components/ui/toggle";
import { useToast } from "@/components/ui/use-toast";
import { SingleChoiceOption } from "./answer-options/SingleChoiceOption";
import { MultipleChoiceOption } from "./answer-options/MultipleChoiceOption";

interface AnswerOptionsProps {
  currentQuestion: Question;
  onQuestionChange: (question: Question) => void;
  onAddOption: () => void;
  onOptionChange: (optionId: string, newText: string) => void;
  onRemoveOption: (optionId: string) => void;
}

export function AnswerOptions({
  currentQuestion,
  onQuestionChange,
  onAddOption,
  onOptionChange,
  onRemoveOption,
}: AnswerOptionsProps) {
  const { toast } = useToast();

  const handleCorrectAnswerChange = (optionId: string) => {
    if (!currentQuestion.multipleCorrect) {
      const updatedOptions = currentQuestion.options?.map(option => ({
        ...option,
        isCorrect: option.id === optionId
      }));
      onQuestionChange({ ...currentQuestion, options: updatedOptions });
    } else {
      const updatedOptions = currentQuestion.options?.map(option => ({
        ...option,
        isCorrect: option.id === optionId ? !option.isCorrect : option.isCorrect
      }));
      onQuestionChange({ ...currentQuestion, options: updatedOptions });
    }
  };

  const handleMultipleCorrectToggle = () => {
    if (!currentQuestion.multipleCorrect) {
      const updatedOptions = currentQuestion.options?.map((option, index) => ({
        ...option,
        isCorrect: index === 0
      }));
      onQuestionChange({ 
        ...currentQuestion, 
        multipleCorrect: true,
        options: updatedOptions 
      });
    } else {
      const correctOptions = currentQuestion.options?.filter(opt => opt.isCorrect) || [];
      const updatedOptions = currentQuestion.options?.map(option => ({
        ...option,
        isCorrect: option.id === correctOptions[0]?.id
      }));
      onQuestionChange({ 
        ...currentQuestion, 
        multipleCorrect: false,
        options: updatedOptions 
      });
    }
  };

  const handleRemoveOption = (optionId: string) => {
    const remainingOptions = currentQuestion.options?.filter(opt => opt.id !== optionId) || [];
    if (remainingOptions.length < 2) {
      toast({
        variant: "destructive",
        title: "Fout",
        description: "Er moeten minimaal twee antwoordopties zijn",
      });
      return;
    }
    onRemoveOption(optionId);
  };

  const handleMediaChange = (optionId: string, mediaUrl: string | undefined, imageSize?: { width: number; height: number }) => {
    const updatedOptions = currentQuestion.options?.map(option => 
      option.id === optionId 
        ? { ...option, mediaUrl, imageSize }
        : option
    );
    onQuestionChange({ ...currentQuestion, options: updatedOptions });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label>Antwoordopties</Label>
        <Toggle
          pressed={currentQuestion.multipleCorrect}
          onPressedChange={handleMultipleCorrectToggle}
          className="ml-2"
        >
          Meerdere correcte antwoorden
        </Toggle>
      </div>

      <div className="space-y-4">
        {currentQuestion.options?.map((option) => (
          currentQuestion.multipleCorrect ? (
            <MultipleChoiceOption
              key={option.id}
              option={option}
              onOptionChange={onOptionChange}
              onCorrectAnswerChange={handleCorrectAnswerChange}
              onRemoveOption={handleRemoveOption}
              onMediaChange={handleMediaChange}
            />
          ) : (
            <SingleChoiceOption
              key={option.id}
              option={option}
              selectedOptionId={currentQuestion.options?.find(opt => opt.isCorrect)?.id}
              onOptionChange={onOptionChange}
              onCorrectAnswerChange={handleCorrectAnswerChange}
              onRemoveOption={handleRemoveOption}
              onMediaChange={handleMediaChange}
            />
          )
        ))}
      </div>

      <Button variant="outline" onClick={onAddOption} className="w-full">
        <Plus className="mr-2 h-4 w-4" />
        Voeg optie toe
      </Button>
    </div>
  );
}
