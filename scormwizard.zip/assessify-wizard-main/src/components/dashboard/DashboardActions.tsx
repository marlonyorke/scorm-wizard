import { Button } from "@/components/ui/button";

interface DashboardActionsProps {
  isSelectionComplete: boolean;
  onNewQuiz: () => void;
}

export function DashboardActions({ isSelectionComplete, onNewQuiz }: DashboardActionsProps) {
  return (
    <div className="flex gap-4 pt-4">
      <Button
        disabled={!isSelectionComplete}
        className="flex-1"
        variant="outline"
      >
        Toetsen
      </Button>
      <Button
        disabled={!isSelectionComplete}
        className="flex-1"
        onClick={onNewQuiz}
      >
        Nieuwe Toets
      </Button>
    </div>
  );
}