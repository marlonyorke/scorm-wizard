
import React from 'react';
import { useQuestions } from '@/contexts/QuestionsContext';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash } from "lucide-react";
import { Question } from '@/types/editor';

const questionTypeLabels: Record<string, string> = {
  'multiple-choice': 'Multiple Choice',
  'mark-words': 'Mark the Words',
  'matching': 'Matching',
  'order': 'Volgorde',
  'drag-drop': 'Drag & Drop',
  'video-interactive': 'Interactieve Video'
};

export function QuestionsList() {
  const { questions, deleteQuestion, setCurrentQuestion, changeQuestionType } = useQuestions();

  const handleQuestionClick = (question: Question) => {
    changeQuestionType(question.type);
    setCurrentQuestion(question);
  };

  // Filter alleen de werkende vraagtypes
  const workingQuestions = questions.filter(q => 
    ['multiple-choice', 'matching', 'order', 'mark-words', 'video-interactive'].includes(q.type)
  );

  console.log("Alle vragen:", questions);
  console.log("Gefilterde vragen:", workingQuestions);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-gray-800 tracking-tight">
        Opgeslagen Vragen
      </h2>
      {workingQuestions.length === 0 ? (
        <p className="text-muted-foreground text-center py-8">
          Nog geen vragen opgeslagen.
        </p>
      ) : (
        <div className="space-y-4">
          {workingQuestions.map((question) => (
            <Card 
              key={question.id}
              className="group hover:bg-gradient-to-r from-purple-50 to-pink-50 transition-all duration-300 cursor-pointer border-transparent hover:border-purple-200 hover:shadow-lg hover:-translate-y-0.5"
              onClick={() => handleQuestionClick(question)}
            >
              <CardContent className="p-5">
                <div className="flex justify-between items-start">
                  <div className="space-y-2">
                    <p className="font-semibold text-lg text-gray-800 group-hover:text-purple-700 transition-colors">
                      {question.name || "Naamloze vraag"}
                    </p>
                    <div className="flex items-center space-x-2">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                        {questionTypeLabels[question.type] || question.type}
                      </span>
                    </div>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    className="opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-100 hover:text-red-600"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteQuestion(question.id);
                    }}
                  >
                    <Trash className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
