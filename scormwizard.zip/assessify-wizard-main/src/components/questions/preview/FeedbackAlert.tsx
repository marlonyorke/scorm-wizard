
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

interface FeedbackAlertProps {
  feedback: string;
}

export function FeedbackAlert({ feedback }: FeedbackAlertProps) {
  return (
    <Alert className="bg-[#F2FCE2] border-none mt-4">
      <AlertTitle className="text-green-800">Feedback</AlertTitle>
      <AlertDescription className="text-green-700">
        {feedback}
      </AlertDescription>
    </Alert>
  );
}
