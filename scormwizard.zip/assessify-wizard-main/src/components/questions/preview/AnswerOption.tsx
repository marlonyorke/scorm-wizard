
import { RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { ResizableImage } from "./ResizableImage";

interface AnswerOptionProps {
  option: {
    id: string;
    text: string;
    mediaUrl?: string;
    imageSize?: {
      width: number;
      height: number;
    };
  };
  isSelected: boolean;
  isMultipleChoice: boolean;
  isDisabled: boolean;
  onSelect: (id: string) => void;
}

export function AnswerOption({
  option,
  isSelected,
  isMultipleChoice,
  isDisabled,
  onSelect,
}: AnswerOptionProps) {
  return (
    <div className="space-y-2">
      <div className="flex items-center space-x-3">
        {isMultipleChoice ? (
          <Checkbox
            checked={isSelected}
            onCheckedChange={() => onSelect(option.id)}
            disabled={isDisabled}
          />
        ) : (
          <RadioGroupItem value={option.id} id={option.id} />
        )}
        <label 
          htmlFor={option.id}
          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
        >
          {option.text}
        </label>
      </div>
      {option.mediaUrl && (
        <div className="pl-8">
          <ResizableImage
            src={option.mediaUrl}
            initialSize={option.imageSize}
            className="rounded-lg"
          />
        </div>
      )}
    </div>
  );
}
