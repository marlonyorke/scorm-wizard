
import { useState, useRef, useEffect } from 'react';

interface ResizableImageProps {
  src: string;
  alt?: string;
  className?: string;
  initialSize?: { width: number; height: number };
  onSizeChange?: (size: { width: number; height: number }) => void;
  style?: React.CSSProperties;
}

export function ResizableImage({ 
  src, 
  alt = "Vraag afbeelding",
  className = "rounded-lg",
  initialSize,
  onSizeChange,
  style 
}: ResizableImageProps) {
  const [size, setSize] = useState<{ width: number; height: number }>(
    initialSize || { width: 300, height: 200 }
  );
  const imageRef = useRef<HTMLImageElement>(null);
  const resizingRef = useRef(false);
  const startPosRef = useRef({ x: 0, y: 0 });
  const startSizeRef = useRef<{ width: number; height: number }>(
    initialSize || { width: 300, height: 200 }
  );

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    resizingRef.current = true;
    startPosRef.current = { x: e.clientX, y: e.clientY };
    startSizeRef.current = { width: size.width, height: size.height };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!resizingRef.current) return;

    const deltaX = e.clientX - startPosRef.current.x;
    const deltaY = e.clientY - startPosRef.current.y;

    const aspectRatio = startSizeRef.current.width / startSizeRef.current.height;
    const newWidth = Math.max(100, startSizeRef.current.width + deltaX);
    const newHeight = newWidth / aspectRatio;

    const newSize = { width: newWidth, height: newHeight };
    setSize(newSize);
    onSizeChange?.(newSize);
  };

  const handleMouseUp = () => {
    resizingRef.current = false;
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
  };

  useEffect(() => {
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  return (
    <div className="relative inline-block group">
      <img
        ref={imageRef}
        src={src}
        alt={alt}
        style={{
          width: size.width,
          height: size.height,
          objectFit: 'contain',
          ...style
        }}
        className={className}
      />
      <div
        className="absolute bottom-0 right-0 w-8 h-8 cursor-se-resize bg-white/80 rounded-bl hover:bg-white transition-colors"
        onMouseDown={handleMouseDown}
      >
        <svg 
          viewBox="0 0 24 24" 
          className="w-full h-full p-1.5 text-gray-600"
        >
          <path 
            fill="currentColor" 
            d="M22 22H20V20H22V22ZM22 18H20V16H22V18ZM18 22H16V20H18V22ZM18 18H16V16H18V18ZM14 22H12V20H14V22ZM22 14H20V12H22V14Z"
          />
        </svg>
      </div>
    </div>
  );
}
