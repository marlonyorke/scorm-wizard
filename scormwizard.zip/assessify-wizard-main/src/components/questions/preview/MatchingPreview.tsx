
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface MatchingPreviewProps {
  text: string;
  pairs?: Array<{
    id: string;
    left: string;
    right: string;
  }>;
  mediaUrl?: string;
  imageSize?: {
    width: number;
    height: number;
  };
}

export function MatchingPreview({ text, pairs, mediaUrl, imageSize }: MatchingPreviewProps) {
  if (!pairs?.length) {
    return <p className="text-muted-foreground">Voeg matching paren toe om een voorbeeld te zien.</p>;
  }

  // Verzamel alle rechterkant opties voor de dropdowns
  const rightOptions = pairs.map(pair => pair.right).filter(Boolean);

  return (
    <div className="space-y-4">
      {text && <h3 className="text-lg font-medium">{text}</h3>}
      
      {mediaUrl && (
        <div className="question-media mb-4">
          <img 
            src={mediaUrl} 
            alt="Question media"
            style={{
              width: imageSize?.width || 300,
              height: imageSize?.height || 200,
              objectFit: 'contain'
            }}
            className="rounded-lg border"
          />
        </div>
      )}

      <div className="space-y-3">
        {pairs.map((pair) => (
          <div key={pair.id} className="flex items-center gap-4">
            <div className="flex-1 p-2 bg-gray-50 rounded-md border">
              {pair.left || <span className="text-gray-400">Linker item...</span>}
            </div>
            <div className="flex-shrink-0">
              <svg className="w-6 h-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </div>
            <div className="flex-1">
              <Select>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Kies een antwoord..." />
                </SelectTrigger>
                <SelectContent>
                  {rightOptions.map((option, index) => (
                    <SelectItem key={index} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
