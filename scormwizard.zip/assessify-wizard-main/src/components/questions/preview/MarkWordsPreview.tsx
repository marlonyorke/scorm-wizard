
import React, { useState } from 'react';
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { Plus, Minus } from "lucide-react";

interface MarkWordsPreviewProps {
  text: string;
  question?: string;
  words: Array<{
    id: string;
    word: string;
    isCorrect: boolean;
  }>;
  showFeedback?: boolean;
  feedback?: string;
  mediaUrl?: string;
  imageSize?: {
    width: number | string;
    height: number | string;
  };
  maxErrors?: number;
}

export function MarkWordsPreview({ 
  text, 
  question, 
  words, 
  feedback,
  mediaUrl,
  imageSize,
  maxErrors = 2
}: MarkWordsPreviewProps) {
  const [selectedWords, setSelectedWords] = useState<Set<string>>(new Set());
  const [isCompleted, setIsCompleted] = useState(false);
  const [isImageEnlarged, setIsImageEnlarged] = useState(false);
  const { toast } = useToast();

  // Verwijder de dakjes uit de tekst
  const cleanText = text.replace(/\^(.*?)\^/g, '$1');
  
  // Extract de woorden tussen dakjes voor de correcte antwoorden
  const correctWordsArray: string[] = [];
  let match;
  const regex = /\^(.*?)\^/g;
  while ((match = regex.exec(text)) !== null) {
    correctWordsArray.push(match[1]);
  }
  const correctWordsSet = new Set(correctWordsArray);

  // Helper functie om leestekens te verwijderen voor vergelijking
  const normalizeWord = (word: string) => {
    return word.replace(/[.,!?;:'"]/g, '').trim();
  };

  // Bereken correcte selecties met genormaliseerde woorden
  const correctlySelected = Array.from(selectedWords).filter(word => 
    correctWordsSet.has(normalizeWord(word))
  ).length;

  // Bereken voortgang gebaseerd op correcte selecties
  const totalWords = correctWordsArray.length;
  const progress = Math.min((correctlySelected / totalWords) * 100, 100);

  const handleWordClick = (word: string) => {
    if (isCompleted) return;

    const newSelected = new Set(selectedWords);
    if (newSelected.has(word)) {
      newSelected.delete(word);
    } else {
      newSelected.add(word);
    }
    setSelectedWords(newSelected);

    // Tel het aantal fouten met genormaliseerde woorden
    const incorrectSelections = Array.from(newSelected).filter(w => 
      !correctWordsSet.has(normalizeWord(w))
    ).length;
    
    // Check of alle juiste woorden zijn gevonden met genormaliseerde woorden
    const allCorrectFound = correctWordsArray.every(correctWord => 
      Array.from(newSelected).some(selectedWord => 
        normalizeWord(selectedWord) === correctWord
      )
    );

    if (allCorrectFound && incorrectSelections <= maxErrors) {
      setIsCompleted(true);
      toast({
        title: "Correct! 🎉",
        description: `Je hebt de opdracht afgerond met ${incorrectSelections} ${incorrectSelections === 1 ? 'fout' : 'fouten'}!`,
      });
    }
  };

  const handleReset = () => {
    setSelectedWords(new Set());
    setIsCompleted(false);
  };

  return (
    <div className="space-y-4 max-w-2xl mx-auto bg-white rounded-lg p-6">
      {mediaUrl && (
        <div className="relative">
          <div className={cn(
            "flex justify-center mb-6 relative group transition-all duration-300",
            isImageEnlarged ? "fixed inset-0 z-50 bg-black/50 items-center" : ""
          )}>
            <div className={cn(
              "relative",
              isImageEnlarged ? "max-w-[90vw] max-h-[90vh]" : ""
            )}>
              <img 
                src={mediaUrl} 
                alt="Vraag afbeelding"
                className={cn(
                  "rounded-lg max-w-full transition-all duration-300",
                  isImageEnlarged ? "max-h-[90vh] w-auto" : ""
                )}
                style={{
                  width: isImageEnlarged ? 'auto' : (imageSize?.width || 300),
                  height: isImageEnlarged ? 'auto' : (imageSize?.height || 300),
                  objectFit: 'contain'
                }}
              />
              <button
                onClick={() => setIsImageEnlarged(!isImageEnlarged)}
                className={cn(
                  "absolute top-2 right-2 p-1.5 rounded-full",
                  "bg-white/90 hover:bg-white shadow-md",
                  "text-gray-700 hover:text-gray-900",
                  "transition-all duration-200",
                  "flex items-center justify-center"
                )}
              >
                {isImageEnlarged ? (
                  <Minus className="w-5 h-5" />
                ) : (
                  <Plus className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {question && (
        <div className="mb-6">
          <h2 className="text-lg font-medium mb-2">{question}</h2>
          <p className="text-gray-600 text-sm">
            Instructie: Klik op een woord om het te selecteren. Klik nogmaals om de selectie ongedaan te maken.
          </p>
        </div>
      )}

      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <p className="text-gray-600 text-sm">Correct geselecteerde woorden</p>
          <span className="text-sm font-medium">{Math.round(progress)}%</span>
        </div>
        <div className="bg-gray-200 rounded-full h-2 overflow-hidden">
          <div 
            className="bg-green-500 h-full transition-all duration-300" 
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-sm text-gray-600 mt-2">
          {totalWords - correctlySelected > 0 
            ? `Nog ${totalWords - correctlySelected} ${totalWords - correctlySelected === 1 ? 'woord' : 'woorden'} te vinden`
            : 'Alle juiste woorden zijn gevonden!'}
        </p>
      </div>
      
      <div className="bg-gray-50 rounded-lg p-6 mb-4">
        <p className="leading-relaxed text-lg">
          {cleanText.split(/\s+/).map((word, index) => {
            const isSelected = selectedWords.has(word);
            const normalizedWord = normalizeWord(word);
            const isCorrectWord = correctWordsSet.has(normalizedWord);
            
            return (
              <React.Fragment key={`${word}-${index}`}>
                <button
                  onClick={() => handleWordClick(word)}
                  disabled={isCompleted}
                  className={cn(
                    "px-1.5 py-0.5 rounded transition-colors",
                    "hover:bg-blue-100",
                    !isSelected && "text-gray-700",
                    isSelected && isCorrectWord && "bg-[#F2FCE2] text-green-800 font-medium border border-green-300",
                    isSelected && !isCorrectWord && "bg-red-50 text-red-800 font-medium border border-red-300",
                    "disabled:cursor-default"
                  )}
                >
                  {word}
                </button>
                {" "}
              </React.Fragment>
            );
          })}
        </p>
      </div>

      <div className="flex justify-center">
        <Button
          variant="outline"
          size="lg"
          onClick={handleReset}
          className="w-full max-w-md"
        >
          Opnieuw proberen
        </Button>
      </div>

      {isCompleted && feedback && (
        <Alert className="bg-[#F2FCE2] border-none mt-4">
          <AlertTitle className="text-green-800">Correct!</AlertTitle>
          <AlertDescription className="text-green-700">
            {feedback}
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
