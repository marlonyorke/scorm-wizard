import React, { useState } from 'react';
import { RadioGroup } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { QuestionImage } from './QuestionImage';
import { AnswerOption } from './AnswerOption';
import { FeedbackAlert } from './FeedbackAlert';

interface MultipleChoicePreviewProps {
  text: string;
  options: Array<{
    id: string;
    text: string;
    isCorrect: boolean;
    mediaUrl?: string;
    imageSize?: {
      width: number;
      height: number;
    };
  }>;
  multipleCorrect?: boolean;
  feedback?: string;
  mediaUrl?: string;
  imageSize?: {
    width: number;
    height: number;
  };
}

export function MultipleChoicePreview({
  text,
  options,
  multipleCorrect = false,
  feedback,
  mediaUrl,
  imageSize,
}: MultipleChoicePreviewProps) {
  const [selectedAnswers, setSelectedAnswers] = useState<Set<string>>(new Set());
  const [isCompleted, setIsCompleted] = useState(false);
  const [isImageEnlarged, setIsImageEnlarged] = useState(false);
  const { toast } = useToast();

  const defaultImageSize = { width: 300, height: 200 };
  const finalImageSize = imageSize || defaultImageSize;

  const handleAnswerChange = (answerId: string) => {
    if (isCompleted) return;

    const newSelected = new Set(selectedAnswers);
    
    if (multipleCorrect) {
      if (newSelected.has(answerId)) {
        newSelected.delete(answerId);
      } else {
        newSelected.add(answerId);
      }
    } else {
      newSelected.clear();
      newSelected.add(answerId);
    }
    
    setSelectedAnswers(newSelected);
  };

  const handleCheck = () => {
    const selectedIds = Array.from(selectedAnswers);
    const correctAnswers = options.filter(opt => opt.isCorrect).map(opt => opt.id);
    
    const isCorrect = selectedIds.length === correctAnswers.length && 
      selectedIds.every(id => correctAnswers.includes(id));

    if (isCorrect) {
      toast({
        title: "Correct! 🎉",
        description: "Je hebt het juiste antwoord gegeven!",
      });
    } else {
      toast({
        variant: "destructive",
        title: "Helaas",
        description: "Dit is niet het juiste antwoord. Probeer het nog eens.",
      });
    }
    setIsCompleted(true);
  };

  const handleReset = () => {
    setSelectedAnswers(new Set());
    setIsCompleted(false);
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto bg-white rounded-lg p-6">
      {mediaUrl && (
        <QuestionImage
          src={mediaUrl}
          imageSize={finalImageSize}
          isEnlarged={isImageEnlarged}
          onToggleEnlarge={() => setIsImageEnlarged(!isImageEnlarged)}
        />
      )}

      <div className="space-y-4">
        <h2 className="text-lg font-medium">{text}</h2>

        <div className="space-y-4">
          {multipleCorrect ? (
            <div className="space-y-4">
              {options.map((option) => (
                <AnswerOption
                  key={option.id}
                  option={option}
                  isSelected={selectedAnswers.has(option.id)}
                  isMultipleChoice={true}
                  isDisabled={isCompleted}
                  onSelect={handleAnswerChange}
                />
              ))}
            </div>
          ) : (
            <RadioGroup 
              value={Array.from(selectedAnswers)[0]}
              onValueChange={handleAnswerChange}
              disabled={isCompleted}
              className="space-y-4"
            >
              {options.map((option) => (
                <AnswerOption
                  key={option.id}
                  option={option}
                  isSelected={selectedAnswers.has(option.id)}
                  isMultipleChoice={false}
                  isDisabled={isCompleted}
                  onSelect={handleAnswerChange}
                />
              ))}
            </RadioGroup>
          )}
        </div>

        <div className="flex space-x-3">
          <Button
            onClick={handleCheck}
            className="flex-1"
            disabled={selectedAnswers.size === 0 || isCompleted}
          >
            Controleer
          </Button>
          <Button
            variant="outline"
            onClick={handleReset}
            className="flex-1"
          >
            Opnieuw
          </Button>
        </div>

        {isCompleted && feedback && <FeedbackAlert feedback={feedback} />}
      </div>
    </div>
  );
}
