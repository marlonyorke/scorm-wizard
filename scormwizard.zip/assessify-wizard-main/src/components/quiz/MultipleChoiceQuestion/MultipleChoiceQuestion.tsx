
import { Question } from "@/types/editor";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

interface MultipleChoiceQuestionProps {
  question: Question;
  answers: string[];
  onAnswerChange: (answers: string[]) => void;
}

export function MultipleChoiceQuestion({ 
  question, 
  answers, 
  onAnswerChange 
}: MultipleChoiceQuestionProps) {
  const handleSingleAnswer = (optionId: string) => {
    onAnswerChange([optionId]);
  };

  const handleMultipleAnswer = (optionId: string, checked: boolean) => {
    const currentAnswers = answers || [];
    const updatedAnswers = checked
      ? [...currentAnswers, optionId]
      : currentAnswers.filter(id => id !== optionId);
    
    onAnswerChange(updatedAnswers);
  };

  if (!question.options) return null;

  return (
    <div className="space-y-2">
      {question.multipleCorrect ? (
        question.options.map(option => (
          <div key={option.id} className="flex items-center space-x-2">
            <Checkbox
              id={option.id}
              checked={answers?.includes(option.id)}
              onCheckedChange={(checked) => 
                handleMultipleAnswer(option.id, checked as boolean)
              }
            />
            <Label htmlFor={option.id}>{option.text}</Label>
          </div>
        ))
      ) : (
        <RadioGroup
          value={answers?.[0]}
          onValueChange={handleSingleAnswer}
          className="space-y-2"
        >
          {question.options.map(option => (
            <div key={option.id} className="flex items-center space-x-2">
              <RadioGroupItem value={option.id} id={option.id} />
              <Label htmlFor={option.id}>{option.text}</Label>
            </div>
          ))}
        </RadioGroup>
      )}
    </div>
  );
}
