
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Download, Loader2 } from "lucide-react";
import { useState } from "react";
import { generateScormPackage } from "@/utils/scormExport";
import { useQuestions } from "@/contexts/QuestionsContext";
import { useToast } from "@/hooks/use-toast";

export type QuestionDisplayMode = 'single-page' | 'multi-page' | 'grouped';

interface ScormExportDialogProps {
  onExportStart?: () => void;
  onExportComplete?: () => void;
}

export function ScormExportDialog({ onExportStart, onExportComplete }: ScormExportDialogProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [displayMode, setDisplayMode] = useState<QuestionDisplayMode>('single-page');
  const [questionsPerGroup, setQuestionsPerGroup] = useState('3');
  const { questions } = useQuestions();
  const { toast } = useToast();

  const handleExport = async () => {
    setIsExporting(true);
    onExportStart?.();

    try {
      await generateScormPackage(questions, {
        displayMode,
        questionsPerGroup: displayMode === 'grouped' ? parseInt(questionsPerGroup) : undefined
      });
      
      toast({
        title: "SCORM Export Succesvol",
        description: "Je quiz is geëxporteerd als SCORM pakket.",
      });
      setIsOpen(false);
      onExportComplete?.();
    } catch (error) {
      console.error('Export error:', error);
      toast({
        variant: "destructive",
        title: "Export mislukt",
        description: error instanceof Error 
          ? error.message 
          : "Er is iets misgegaan tijdens het exporteren. Probeer het opnieuw.",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <Download className="mr-2 h-4 w-4" />
          Exporteer SCORM
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>SCORM Export Instellingen</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="space-y-4">
            <Label>Weergave van vragen</Label>
            <RadioGroup
              value={displayMode}
              onValueChange={(value) => setDisplayMode(value as QuestionDisplayMode)}
              className="grid gap-3"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="single-page" id="single-page" />
                <Label htmlFor="single-page">Alle vragen op één pagina</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="multi-page" id="multi-page" />
                <Label htmlFor="multi-page">Elke vraag op een nieuwe pagina</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="grouped" id="grouped" />
                <Label htmlFor="grouped">Groeperen van vragen</Label>
              </div>
            </RadioGroup>
          </div>

          {displayMode === 'grouped' && (
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="questions-per-group" className="col-span-3">
                Aantal vragen per groep
              </Label>
              <Input
                id="questions-per-group"
                type="number"
                value={questionsPerGroup}
                onChange={(e) => setQuestionsPerGroup(e.target.value)}
                min="2"
                max="10"
                className="col-span-1"
              />
            </div>
          )}
        </div>

        <div className="flex justify-end">
          <Button onClick={handleExport} disabled={isExporting}>
            {isExporting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Bezig met exporteren...
              </>
            ) : (
              <>
                <Download className="mr-2 h-4 w-4" />
                Exporteren
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
