import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { Question } from '@/types/editor';

interface QuestionsContextType {
  questions: Question[];
  selectedQuestionTypes: string[];
  currentQuestion: Question | null;
  addQuestion: (question: Question) => void;
  updateQuestion: (id: string, question: Question) => void;
  deleteQuestion: (id: string) => void;
  setSelectedQuestionTypes: (types: string[]) => void;
  setCurrentQuestion: (question: Question | null) => void;
  createInitialQuestion: (type: 'multiple-choice' | 'mark-words' | 'matching' | 'order' | 'drag-drop' | 'video-interactive') => Question;
  changeQuestionType: (type: 'multiple-choice' | 'mark-words' | 'matching' | 'order' | 'drag-drop' | 'video-interactive') => void;
}

const QuestionsContext = createContext<QuestionsContextType | undefined>(undefined);

// Keys voor localStorage
const STORAGE_KEYS = {
  QUESTIONS: 'editor_questions',
  SELECTED_TYPES: 'editor_selected_types',
  CURRENT_QUESTION: 'editor_current_question'
};

export function QuestionsProvider({ children }: { children: React.ReactNode }) {
  // Initialize state from localStorage if available
  const [questions, setQuestions] = useState<Question[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.QUESTIONS);
    return stored ? JSON.parse(stored) : [];
  });

  const [selectedQuestionTypes, setSelectedQuestionTypes] = useState<string[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.SELECTED_TYPES);
    return stored ? JSON.parse(stored) : [];
  });

  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.CURRENT_QUESTION);
    return stored ? JSON.parse(stored) : null;
  });

  // Sync state to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(questions));
  }, [questions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SELECTED_TYPES, JSON.stringify(selectedQuestionTypes));
  }, [selectedQuestionTypes]);

  useEffect(() => {
    if (currentQuestion) {
      console.log("Saving current question to localStorage:", currentQuestion);
      localStorage.setItem(STORAGE_KEYS.CURRENT_QUESTION, JSON.stringify(currentQuestion));
    }
  }, [currentQuestion]);

  const createInitialQuestion = useCallback((type: 'multiple-choice' | 'mark-words' | 'matching' | 'order' | 'drag-drop' | 'video-interactive'): Question => {
    console.log("Creating initial question for type:", type);
    
    const baseQuestion = {
      id: crypto.randomUUID(),
      name: '',
      text: '',
      feedback: '',
    };

    switch (type) {
      case 'multiple-choice':
        return {
          ...baseQuestion,
          type: 'multiple-choice',
          options: [
            { id: crypto.randomUUID(), text: '', isCorrect: false },
            { id: crypto.randomUUID(), text: '', isCorrect: false }
          ],
          multipleCorrect: false
        };
      case 'mark-words':
        return {
          ...baseQuestion,
          type: 'mark-words',
          words: [],
          question: ''
        };
      case 'matching':
        return {
          ...baseQuestion,
          type: 'matching',
          pairs: Array.from({ length: 4 }, () => ({
            id: crypto.randomUUID(),
            left: '',
            right: ''
          }))
        };
      case 'order':
        return {
          ...baseQuestion,
          type: 'order',
          items: Array.from({ length: 4 }, (_, index) => ({
            id: crypto.randomUUID(),
            text: '',
            correctPosition: index + 1
          }))
        };
      case 'drag-drop':
        return {
          ...baseQuestion,
          type: 'drag-drop',
          items: [],
          dropZones: []
        };
      case 'video-interactive':
        return {
          ...baseQuestion,
          type: 'video-interactive',
          videoUrl: '',
          markers: []
        };
      default:
        console.error("Unknown question type:", type);
        return baseQuestion as Question;
    }
  }, []);

  const changeQuestionType = useCallback((type: 'multiple-choice' | 'mark-words' | 'matching' | 'order' | 'drag-drop' | 'video-interactive') => {
    console.log("Changing question type to:", type);
    if (currentQuestion?.type === type) {
      console.log("Already on this question type, no change needed");
      return;
    }

    const newQuestion = createInitialQuestion(type);
    console.log("Created new question for type change:", newQuestion);
    setCurrentQuestion(newQuestion);
  }, [currentQuestion?.type, createInitialQuestion]);

  const addQuestion = useCallback((question: Question) => {
    console.log("Adding question:", question);
    setQuestions(prev => [...prev, question]);
  }, []);

  const updateQuestion = useCallback((id: string, updatedQuestion: Question) => {
    console.log("Updating question:", id, updatedQuestion);
    setQuestions(prev =>
      prev.map((q) => (q.id === id ? updatedQuestion : q))
    );
  }, []);

  const deleteQuestion = useCallback((id: string) => {
    console.log("Deleting question:", id);
    setQuestions(prev => prev.filter((q) => q.id !== id));
  }, []);

  return (
    <QuestionsContext.Provider
      value={{ 
        questions, 
        selectedQuestionTypes,
        currentQuestion,
        addQuestion, 
        updateQuestion, 
        deleteQuestion,
        setSelectedQuestionTypes,
        setCurrentQuestion,
        createInitialQuestion,
        changeQuestionType
      }}
    >
      {children}
    </QuestionsContext.Provider>
  );
}

export function useQuestions() {
  const context = useContext(QuestionsContext);
  if (context === undefined) {
    throw new Error('useQuestions must be used within a QuestionsProvider');
  }
  return context;
}
