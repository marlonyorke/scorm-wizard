import { SCORMAPI } from '@/utils/scormAPI';

declare global {
  interface Window {
    API?: SCORMAPI;
  }
}