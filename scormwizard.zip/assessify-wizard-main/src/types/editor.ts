
export interface QuestionOption {
  id: string;
  text: string;
  isCorrect: boolean;
  mediaUrl?: string;
  imageSize?: {
    width: number;
    height: number;
  };
}

export interface MatchingPair {
  id: string;
  left: string;
  right: string;
}

export interface OrderItem {
  id: string;
  text: string;
  correctPosition: number;
}

export interface DragDropItem {
  id: string;
  text: string;
}

export interface DragDropZone {
  id: string;
  beforeText: string;
  afterText: string;
  correctItemId: string;
}

export interface VideoMarker {
  id: string;
  time: number;
  question: {
    text: string;
    options: QuestionOption[];
  };
}

export interface Question {
  id: string;
  name: string;
  type: 'multiple-choice' | 'mark-words' | 'matching' | 'order' | 'drag-drop' | 'video-interactive';
  text: string;
  question?: string;
  feedback: string;
  options?: QuestionOption[];
  words?: Array<{
    id: string;
    word: string;
    isCorrect: boolean;
  }>;
  pairs?: MatchingPair[];
  items?: OrderItem[] | DragDropItem[];
  shuffleOptions?: boolean;
  mediaUrl?: string;
  imageSize?: {
    width: number;
    height: number;
  };
  multipleCorrect?: boolean;
  dropZones?: DragDropZone[];
  maxErrors?: number;
  // Nieuwe velden voor video-interactive type
  videoUrl?: string;
  markers?: VideoMarker[];
}
