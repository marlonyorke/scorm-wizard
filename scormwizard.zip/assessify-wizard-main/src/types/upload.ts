export interface UploadedFile {
  id: string;
  name: string;
  size: number;
  type: string;
}