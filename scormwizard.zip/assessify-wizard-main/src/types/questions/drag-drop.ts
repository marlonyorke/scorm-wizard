
import { BaseQuestionData } from "./base";
import { ValidationError } from "@/components/editor/question-editors/base/BaseQuestionEditor";

export interface DraggableItem {
  id: string;
  text: string;
}

export interface DropZone {
  id: string;
  beforeText: string;
  afterText: string;
  correctItemId: string;
}

export interface DragDropQuestionData extends BaseQuestionData {
  type: 'drag-drop';
  items: DraggableItem[];
  dropZones: DropZone[];
}

export const DragDropDefinition = {
  type: 'drag-drop',
  createInitialState: (): DragDropQuestionData => ({
    id: crypto.randomUUID(),
    type: 'drag-drop',
    name: '',
    text: '',
    items: [],
    dropZones: [],
  }),
  validate: (question: DragDropQuestionData): ValidationError[] => {
    const errors: ValidationError[] = [];

    if (!question.text.trim()) {
      errors.push({
        field: 'text',
        message: 'Voer een vraag in'
      });
    }

    if (question.items.length === 0) {
      errors.push({
        field: 'items',
        message: 'Voeg minimaal één sleepbaar item toe'
      });
    }

    if (question.dropZones.length === 0) {
      errors.push({
        field: 'dropZones',
        message: 'Voeg minimaal één dropzone toe'
      });
    }

    const allItemsHaveText = question.items.every(item => item.text.trim());
    if (!allItemsHaveText) {
      errors.push({
        field: 'items',
        message: 'Alle sleepbare items moeten tekst bevatten'
      });
    }

    const allDropZonesHaveCorrectItem = question.dropZones.every(
      zone => question.items.some(item => item.id === zone.correctItemId)
    );
    if (!allDropZonesHaveCorrectItem) {
      errors.push({
        field: 'dropZones',
        message: 'Alle dropzones moeten een correct antwoord hebben'
      });
    }

    return errors;
  },
  isComplete: (question: DragDropQuestionData): boolean => {
    return (
      question.text.trim() !== '' &&
      question.items.length > 0 &&
      question.dropZones.length > 0 &&
      question.items.every(item => item.text.trim()) &&
      question.dropZones.every(zone => 
        question.items.some(item => item.id === zone.correctItemId)
      )
    );
  }
};

