import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import Editor from "@/pages/editor";
import QuestionTypeSelection from "@/pages/QuestionTypeSelection";
import { QuestionsProvider } from "@/contexts/QuestionsContext";
import Index from "@/pages/Index";
import ScormPage from "@/pages/scorm";

function App() {
  return (
    <BrowserRouter>
      <QuestionsProvider>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/question-types" element={<QuestionTypeSelection />} />
          <Route path="/editor" element={<Editor />} />
          <Route path="/scorm" element={<ScormPage />} />
        </Routes>
        <Toaster />
      </QuestionsProvider>
    </BrowserRouter>
  );
}

export default App;