import { ContentUpload } from "@/components/upload/ContentUpload";

export default function Upload() {
  return <ContentUpload />;
}