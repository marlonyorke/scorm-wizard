
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { QuestionTypeCard } from "@/components/questions/QuestionTypeCard";
import { QuestionType, TotalStats } from "@/types/questions";
import { useQuestions } from "@/contexts/QuestionsContext";

const initialQuestionTypes: QuestionType[] = [
  { id: "multiple-choice", name: "Multiple Choice", icon: "ListChecks", aiAssist: false },
  { id: "mark-words", name: "Mark the Words", icon: "TextSelect", aiAssist: false },
  { id: "matching", name: "Matching", icon: "GitMerge", aiAssist: false },
  { id: "order", name: "Volgorde", icon: "ArrowUpDown", aiAssist: false },
  { id: "drag-drop", name: "Drag & Drop", icon: "GripHorizontal", aiAssist: false },
  { id: "open", name: "Open Vraag", icon: "MessageSquare", aiAssist: false },
  { id: "hotspot", name: "Hotspot", icon: "Target", aiAssist: false },
  { id: "fill-blanks", name: "Invulvraag", icon: "PenLine", aiAssist: false },
  { id: "interactive-video", name: "Interactive Video", icon: "Video", aiAssist: false }
];

export default function QuestionTypeSelection() {
  const navigate = useNavigate();
  const [questionTypes] = useState<QuestionType[]>(initialQuestionTypes);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const { setSelectedQuestionTypes, createInitialQuestion, setCurrentQuestion } = useQuestions();

  const calculateTotals = (): TotalStats => {
    return {
      totalQuestions: questionTypes.length,
      aiAssistedTypes: questionTypes.filter(type => type.aiAssist).length,
      estimatedDuration: questionTypes.length * 2,
      maxScore: questionTypes.length * 10
    };
  };

  const handleTypeSelect = (typeId: string) => {
    setSelectedTypes(prev => {
      if (prev.includes(typeId)) {
        return prev.filter(id => id !== typeId);
      }
      return [...prev, typeId];
    });
  };

  const handleProceedToEditor = () => {
    // Ensure we're only passing valid question types
    const validTypes = selectedTypes.filter(type => 
      ['multiple-choice', 'mark-words', 'matching', 'order', 'drag-drop'].includes(type)
    );
    
    console.log("Selected question types:", validTypes);
    
    if (validTypes.length > 0) {
      // Eerst de eerste vraag aanmaken
      const firstType = validTypes[0] as 'multiple-choice' | 'mark-words' | 'matching' | 'order' | 'drag-drop';
      const initialQuestion = createInitialQuestion(firstType);
      console.log("Created initial question before navigation:", initialQuestion);
      
      // Dan pas de types setten en navigeren
      setSelectedQuestionTypes(validTypes);
      setCurrentQuestion(initialQuestion);
      navigate('/editor');
    }
  };

  const totals = calculateTotals();
  const hasQuestions = selectedTypes.length > 0;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="container mx-auto max-w-5xl">
        <div className="flex flex-col items-center mb-12">
          <h1 className="text-4xl font-bold gold-gradient bg-clip-text text-transparent mb-4">
            Vraagtype Selectie
          </h1>
          <p className="text-muted-foreground text-center max-w-2xl">
            Kies de vraagtypes die je wilt gebruiken in je quiz. 
            Combineer verschillende types voor een gevarieerde leerervaring.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {questionTypes.map((type) => (
            <div key={type.id} className="animate-fade-in">
              <QuestionTypeCard
                type={type}
                isSelected={selectedTypes.includes(type.id)}
                onSelect={handleTypeSelect}
              />
            </div>
          ))}
        </div>

        <div className="glass-card rounded-2xl p-8">
          <h2 className="text-2xl font-semibold mb-6 gold-gradient bg-clip-text text-transparent">Overzicht</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center">
                  <span className="text-2xl font-bold text-primary">{selectedTypes.length}</span>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Geselecteerde types</p>
                  <p className="font-medium text-foreground">{selectedTypes.length} van {totals.totalQuestions}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center">
                  <span className="text-2xl font-bold text-primary">{totals.estimatedDuration}</span>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Geschatte tijdsduur</p>
                  <p className="font-medium text-foreground">{totals.estimatedDuration} minuten</p>
                </div>
              </div>
            </div>
            <div className="flex items-end justify-end">
              <Button
                onClick={handleProceedToEditor}
                disabled={!hasQuestions}
                className="gold-gradient hover:opacity-90 text-primary-foreground px-8 py-6 rounded-xl font-semibold shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed hover:gold-glow"
              >
                Doorgaan naar Editor
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
