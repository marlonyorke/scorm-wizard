
import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Question } from "@/types/editor";
import { useQuestions } from "@/contexts/QuestionsContext";
import { useToast } from "@/components/ui/use-toast";
import { QuestionsList } from "@/components/questions/QuestionsList";
import { EditorHeader } from "@/components/editor/EditorHeader";
import { QuestionEditorForm } from "@/components/editor/QuestionEditorForm";
import { QuestionTypeTabs } from "@/components/editor/QuestionTypeTabs";

export default function Editor() {
  const { 
    selectedQuestionTypes, 
    currentQuestion, 
    setCurrentQuestion,
    createInitialQuestion,
    addQuestion 
  } = useQuestions();
  
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);

  // Wacht tot de currentQuestion is geladen voordat we de editor tonen
  useEffect(() => {
    if (currentQuestion !== null) {
      setIsLoading(false);
    }
  }, [currentQuestion]);

  const handleSaveQuestion = () => {
    if (!currentQuestion) return;

    const validationErrors = validateQuestion(currentQuestion);

    if (validationErrors.length > 0) {
      toast({
        variant: "destructive",
        title: "Fout bij opslaan",
        description: validationErrors.join(", "),
      });
      return;
    }

    addQuestion(currentQuestion);
    toast({
      title: "Vraag opgeslagen",
      description: "De vraag is succesvol opgeslagen.",
    });

    // Create a new question of the same type
    const newQuestion = createInitialQuestion(currentQuestion.type);
    setCurrentQuestion(newQuestion);
  };

  const validateQuestion = (question: Question): string[] => {
    const errors: string[] = [];

    if (!question.text.trim()) {
      errors.push("Voer een vraag in");
    }

    if (question.type === 'multiple-choice') {
      if (!question.options || question.options.length < 2) {
        errors.push("Voeg minimaal twee antwoordopties toe");
      } else {
        const hasValidOptions = question.options.some(option => option.text.trim());
        if (!hasValidOptions) {
          errors.push("Vul minimaal één antwoordoptie in");
        }

        const hasCorrectAnswer = question.options.some(option => option.isCorrect);
        if (!hasCorrectAnswer) {
          errors.push("Selecteer minimaal één correct antwoord");
        }
      }
    } else if (question.type === 'mark-words') {
      if (!question.words || question.words.length === 0) {
        errors.push("Markeer minimaal één woord in de tekst");
      }
    } else if (question.type === 'video-interactive') {
      if (!question.videoUrl) {
        errors.push("Upload een video");
      }
    }

    return errors;
  };

  const handleAddOption = () => {
    if (!currentQuestion) return;
    
    const newQuestion: Question = {
      ...currentQuestion,
      options: [
        ...(currentQuestion.options || []),
        {
          id: crypto.randomUUID(),
          text: "",
          isCorrect: false,
        }
      ]
    };
    setCurrentQuestion(newQuestion);
  };

  const handleOptionChange = (optionId: string, newText: string) => {
    if (!currentQuestion) return;
    
    const newQuestion: Question = {
      ...currentQuestion,
      options: currentQuestion.options?.map((opt) =>
        opt.id === optionId ? { ...opt, text: newText } : opt
      )
    };
    setCurrentQuestion(newQuestion);
  };

  const handleRemoveOption = (optionId: string) => {
    if (!currentQuestion) return;
    
    const newQuestion: Question = {
      ...currentQuestion,
      options: currentQuestion.options?.filter((opt) => opt.id !== optionId)
    };
    setCurrentQuestion(newQuestion);
  };

  // Toon niets tijdens het laden
  if (isLoading) {
    return null;
  }

  // Als het laden klaar is maar er is geen vraag, return null
  if (!currentQuestion) {
    return null;
  }

  return (
    <div className="container mx-auto p-6 max-w-5xl">
      <div className="glass-card rounded-xl p-4 mb-6">
        <EditorHeader onSave={handleSaveQuestion} />
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-1">
          <Card className="glass-card">
            <CardContent className="p-4">
              <QuestionsList />
            </CardContent>
          </Card>
        </div>

        <div className="col-span-2 space-y-6">
          <Card className="glass-card">
            <CardContent className="pt-6 px-6">
              <QuestionTypeTabs />
            </CardContent>
          </Card>

          <Card className="glass-card transition-all duration-300 hover:gold-glow">
            <CardContent className="p-6">
              <QuestionEditorForm
                currentQuestion={currentQuestion}
                onQuestionChange={setCurrentQuestion}
                onAddOption={handleAddOption}
                onOptionChange={handleOptionChange}
                onRemoveOption={handleRemoveOption}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
